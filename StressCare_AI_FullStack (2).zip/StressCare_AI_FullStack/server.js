require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const OLLAMA_URL = (process.env.OLLAMA_URL || "http://127.0.0.1:11434").replace(/\/$/, "");
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "llama3.2";

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", app: "StressCare AI API", model: OLLAMA_MODEL });
});

app.post("/api/chat", async (req, res) => {
  const message = typeof req.body.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "Please enter a message." });
  if (message.length > 2000) return res.status(400).json({ error: "Message is too long. Please keep it under 2000 characters." });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 90000);

  try {
    const ollamaResponse = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        stream: false,
        messages: [
          {
            role: "system",
            content: "You are StressCare AI, a kind and non-judgmental wellbeing support assistant. Give brief, practical, general stress-management suggestions. Do not diagnose or claim to be a therapist. Encourage contacting a qualified mental-health professional for persistent or severe distress. If someone may be in immediate danger or might harm themselves, encourage them to contact local emergency services and a trusted person immediately."
          },
          { role: "user", content: message }
        ]
      })
    });

    if (!ollamaResponse.ok) {
      const detail = await ollamaResponse.text();
      return res.status(502).json({
        error: `Ollama returned an error (${ollamaResponse.status}). Check that Ollama is running and that model "${OLLAMA_MODEL}" is installed.`,
        detail: detail.slice(0, 300)
      });
    }

    const result = await ollamaResponse.json();
    const reply = result.message && result.message.content;
    if (!reply) return res.status(502).json({ error: "The AI model returned an empty response." });
    res.json({ reply, model: OLLAMA_MODEL });
  } catch (error) {
    const messageText = error.name === "AbortError"
      ? "The AI request timed out. Please try again."
      : "Cannot connect to Ollama. Start Ollama and make sure it is available at " + OLLAMA_URL + ".";
    res.status(503).json({ error: messageText });
  } finally {
    clearTimeout(timeout);
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`StressCare AI is running at http://localhost:${PORT}`);
  console.log(`Using Ollama model: ${OLLAMA_MODEL}`);
});
