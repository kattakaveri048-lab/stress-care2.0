# StressCare AI — Full-Stack Mini Project

This folder contains:
- `public/index.html` — frontend (HTML, CSS and browser JavaScript)
- `server.js` — Node.js + Express backend
- `POST /api/chat` — sends chat messages to a locally running Ollama model
- `GET /api/health` — checks that the backend is running

## Requirements
1. Install Node.js 18 or newer.
2. Install Ollama from https://ollama.com/.
3. Open Command Prompt and download a model once:
   ```bash
   ollama pull llama3.2
   ```

## Run the project on Windows
1. Extract this ZIP file.
2. Open the extracted `StressCare_AI_FullStack` folder.
3. Click the File Explorer address bar, type `cmd`, and press Enter.
4. In Command Prompt, run:
   ```bash
   npm install
   ```
5. Copy `.env.example` and name the copy `.env` (or use the defaults).
6. Make sure Ollama is running. If needed, open another Command Prompt and run:
   ```bash
   ollama serve
   ```
   If Ollama is already running in the background, you do not need to run this command again.
7. In the project Command Prompt, run:
   ```bash
   npm start
   ```
8. Open this address in Chrome:
   http://localhost:3000

## Change the Ollama model
Edit `.env` and set `OLLAMA_MODEL` to a model already installed on your computer, for example `llama3.2` or `mistral`.

## Important deployment note
GitHub Pages hosts static frontend files only. It cannot run this Node.js backend or connect to your computer's local Ollama service. To make the complete application available publicly, deploy the Node.js server to a backend host and configure a cloud-hosted model/API endpoint. Do not publish API keys or private credentials in GitHub.

## Project limitations and safety
- The login/signup screen in this prototype is a demonstration only; it does not create real accounts.
- This starter project does not include a database or persistent chat history.
- The chatbot offers general wellbeing information and is not a medical professional, diagnosis, or emergency service.
